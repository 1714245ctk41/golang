# How to Build a Search Service with Go and Elasticsearch

Source code for the [How to Build a Search Service with Go and Elasticsearch](https://outcrawl.com/go-elastic-search-service/) article.
