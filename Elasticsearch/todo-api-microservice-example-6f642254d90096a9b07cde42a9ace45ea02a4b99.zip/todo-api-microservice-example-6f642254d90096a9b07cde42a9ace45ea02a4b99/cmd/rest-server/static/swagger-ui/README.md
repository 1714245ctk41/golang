# Swagger UI

Version used is [Swagger UI v3.44.1](https://github.com/swagger-api/swagger-ui/releases/tag/v3.44.1).
