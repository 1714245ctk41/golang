DROP TABLE tasks;

DROP TYPE priority;

DROP EXTENSION IF EXISTS "uuid-ossp";
