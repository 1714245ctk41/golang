package constant

const (
	ADMIN = "ADMIN"
	USER = "USER"
)
